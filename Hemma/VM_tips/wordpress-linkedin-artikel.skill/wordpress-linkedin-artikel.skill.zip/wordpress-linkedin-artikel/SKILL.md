---
name: wordpress-linkedin-artikel
description: >-
  Skapar välformaterade HTML-filer för publicering på WordPress-blogg och LinkedIn
  Pulse — med korrekt hantering av svenska tecken (å, ä, ö), rätt rubrikstruktur
  och Kents personliga röst. Aktivera alltid när Kent vill publicera en text på sin
  blogg (controllerutangranser.wordpress.com) eller skriva en LinkedIn Pulse-artikel,
  även om han bara säger "skriv en bloggtext", "gör en LinkedIn-artikel", "publicera
  detta", "anpassa för WordPress" eller "anpassa för Pulse". Bygger på och förutsätter
  att humanizer_ton och linkedin_pulse-skills finns tillgängliga — dessa gäller
  parallellt och ska alltid följas för ton, röst och LinkedIn-struktur.
metadata:
  projekt: Ekonomi / VM_tips och liknande
  beroende-skills: linkedin_pulse/SKILL.md, humanizer_ton/SKILL.md
  senast uppdaterad: 2026-06-10
---

## Vad skillet gör

Producerar **två separata filer** per artikel:

| Fil | Användning |
|-----|-----------|
| `[artikelnamn]_wordpress.html` | Klistra in i WordPress HTML-editor |
| `[artikelnamn]_linkedin_pulse.html` | Öppna i browser → Ctrl+A → Ctrl+C → klistra in i LinkedIn "Skriv en artikel" |

Båda filerna ska fungera felfritt direkt — utan att Kent behöver justera tecken,
rubriker eller struktur manuellt.

---

## Del 1 — Svenska tecken: den viktigaste regeln

**Alla HTML-filer MÅSTE ha `<meta charset="UTF-8">` i `<head>`.**

Utan den kommer webbläsaren att gissa teckenkodning och tolka å, ä och ö fel —
de visas som `Ã¥`, `Ã¤`, `Ã¶` eller liknande skräptecken.

```html
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Artikelns titel</title>
</head>
```

**Skriv alltid å, ä, ö direkt som UTF-8-tecken i texten** — inte som HTML-entiteter
(`&aring;`, `&auml;`, `&ouml;`). HTML-entiteter gör texten oläslig i editorn och
är onödiga när charset är korrekt satt.

---

## Del 2 — WordPress HTML-fil

### Filstruktur

WordPress-filen är ett fullständigt HTML-dokument med två syften:
1. **Förhandsgranskning i webbläsaren** — Kent kan dubbelklicka och se hur det ser ut
2. **Inklistringsunderlag** — Kent kopierar märkt sektion och klistrar in i WP

```html
<!DOCTYPE html>
<html lang="sv">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Förhandsgranskning – [Artikelns titel]</title>
  <style>
    /* Förhandsgranskningsstil – syns INTE i WordPress */
    body {
      font-family: Georgia, "Times New Roman", serif;
      font-size: 17px;
      line-height: 1.75;
      color: #222;
      max-width: 720px;
      margin: 48px auto;
      padding: 0 24px;
    }
    h2 { font-size: 24px; margin-top: 40px; margin-bottom: 10px; }
    h3 { font-size: 20px; margin-top: 32px; margin-bottom: 8px; }
    p  { margin: 0 0 18px; }
    a  { color: #0066cc; }
    hr { border: none; border-top: 1px solid #ccc; margin: 40px 0 24px; }
    em { color: #555; }
    .sources p { font-size: 14px; color: #666; margin-bottom: 8px; }
  </style>
</head>
<body>

<!-- ══ KLISTRA IN HÄRIFRÅN ══ -->

<h2>Artikelrubrik</h2>
<p>Brödtext...</p>
<h3>Sektionsrubrik</h3>
<p>Mer text...</p>

<!-- ══ SLUT PÅ INKLISTRING ══ -->

</body>
</html>
```

### WordPress rubrikhierarki

| HTML-tagg | Användning i WP |
|-----------|----------------|
| `<h2>` | Artikelns huvudrubrik (WordPress använder H1 för sidtiteln) |
| `<h3>` | Sektionsrubriker i artikeln |
| `<h4>` | Underrubriker vid behov |
| `<strong>` | Fetstil för begrepp och nyckelord |
| `<em>` | Kursiv för titlar och källhänvisningar |

### WordPress inklistringsinstruktion (lägg alltid i HTML-kommentar överst)

```html
<!--
  WORDPRESS: Kopiera allt mellan "KLISTRA IN HÄRIFRÅN" och
  "SLUT PÅ INKLISTRING". I Gutenberg: lägg till ett
  "Anpassad HTML"-block och klistra in. I klassisk editor:
  klicka fliken "Text" (inte "Visuell").
-->
```

---

## Del 3 — LinkedIn Pulse HTML-fil

LinkedIn Pulse-editorn tar emot formaterad text via urklippet — men bara om
filen är korrekt kodad och öppnas i en webbläsare. Kom ihåg: LinkedIn Pulse
nås via "Skriv en artikel", **inte** "Skapa ett inlägg".

### Instruktionskommentar (lägg alltid överst i filen)

```html
<!--
  LINKEDIN PULSE:
  1. Öppna filen i Chrome eller Edge
  2. Tryck Ctrl+A (markera allt) → Ctrl+C (kopiera)
  3. Gå till LinkedIn → klicka "Skriv en artikel"
  4. Klistra in (Ctrl+V) — rubriker, fetstil och länkar följer med
  5. Klicka sedan på H1-rubriken i Pulse-editorn och välj "Rubrik"
     om den inte är korrekt formaterad
-->
```

### HTML-struktur för LinkedIn Pulse

```html
<!DOCTYPE html>
<html lang="sv">
<head>
  <meta charset="UTF-8">
  <title>[Artikelns titel]</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      font-size: 16px;
      line-height: 1.7;
      color: #1a1a1a;
      max-width: 680px;
      margin: 40px auto;
      padding: 0 24px;
    }
    h1  { font-size: 32px; font-weight: 700; margin-bottom: 24px; line-height: 1.2; }
    h2  { font-size: 22px; font-weight: 700; margin-top: 36px; margin-bottom: 12px; }
    p   { margin: 0 0 16px; }
    a   { color: #0a66c2; text-decoration: none; }
    hr  { border: none; border-top: 1px solid #ddd; margin: 36px 0 20px; }
    em  { font-style: italic; color: #555; }
    .hashtags { margin-top: 24px; color: #0a66c2; font-weight: 500; }
    .sources p { font-size: 13px; color: #555; margin-bottom: 6px; }
  </style>
</head>
<body>
  <h1>Kort, slagkraftig titel (1–3 ord helst)</h1>
  <p><strong>Hook — funkar som fristående mening i flödesförhandsgranskn.</strong></p>
  <p>Öppningsstycke: konkret situation, vad som hände.</p>

  <h2>Sektionsrubrik</h2>
  <p>...</p>

  <h2>Vad det visar</h2>
  <p>...</p>

  <p>🔗 <a href="[länk]">[länktext]</a></p>
  <p>📝 <a href="[blogg]">[blogg]</a></p>

  <p class="hashtags">#Tag1 #Tag2 #Tag3 #Tag4 #Tag5</p>

  <hr>
  <div class="sources">
    <p><strong>Källförteckning (Harvard)</strong></p>
    <p>Efternamn, I. (år). <em>Titel.</em> Förlag/Plattform. URL</p>
  </div>
</body>
</html>
```

### LinkedIn Pulse-regler (från linkedin_pulse/SKILL.md)

- **Titel:** 1–3 ord ger bäst räckvidd (se "Karaktär", 1 300+ visningar)
- **Hook (rad 1–3):** ska fungera helt fristående — det enda som syns i flödet
- **Stycken:** max 3–4 meningar per stycke, aldrig längre
- **Hashtags:** exakt 3–5 stycken — inte fler
- **Avslut:** öppen fråga eller tydligt ställningstagande — aldrig generisk summering
- **Källförteckning:** Harvardformat i slutet (Kents röst, signalerar seriositet)

---

## Del 4 — Humanizer-pass (från humanizer_ton/SKILL.md)

Kör alltid dessa pass på texten innan filerna skapas:

1. **Steg 1 – Förstärkningsord:** stryk *utmärkt*, *exemplarisk*, *möjliggöra*, *säkerställa* etc.
2. **Steg 4 – Rytmpasset:** variera meningslängd, bryt tre-i-rad-meningar
3. **Steg 5 – Specificeringspasset:** ersätt "nyligen" med datum, "många" med antal, "en aktör" med namn
4. **Steg 6 – Åsiktspasset:** ta bort "det beror på" — vad tycker Kent egentligen?
5. **Steg 7 – Röstpasset:** öppna med scen/fråga/observation (aldrig definition), rör sig från personligt → generellt, avsluta med öppenhet

---

## Procedur

### Steg 1 — Klarlägg

Om inte rubrik och innehåll är tydliga: fråga vad artikeln handlar om, vilken
vinkel och vem målgruppen är. Ge sedan 3 förslag på upplägg (rubrik + punktlista)
och vänta på Kents val.

### Steg 2 — Skriv text

Skriv artikeltexten med humanizer-passen inbyggda. Håll LinkedIn-versionen kortare
(400–700 ord) och bloggen längre (700–1 200 ord).

### Steg 3 — Skapa filerna

Skapa båda HTML-filerna enligt mallarna ovan. Spara i Kents aktiva projektmapp.

### Steg 4 — Ingress till LinkedIn (fråga alltid)

Ge tre förslag på ingress (den korta texten som visas i flödet under rubriken):
- Ett **provokativt/korthuggit**
- Ett **personligt/berättande**
- Ett **yrkesriktat**

Ingressen klistras in manuellt i LinkedIn Pulse-editorns ingresruta och ska vara
max ~300 tecken.

### Steg 5 — Kontrollista

Innan leverans, verifiera:
- ✅ Båda filerna har `<meta charset="UTF-8">`
- ✅ å, ä, ö skrivna direkt som UTF-8 (inte HTML-entiteter)
- ✅ WordPress-filen har inklistringskommentar med tydliga instruktioner
- ✅ LinkedIn-filen har instruktionskommentar (Ctrl+A → Ctrl+C → klistra i Pulse)
- ✅ Humanizer-pass genomförda
- ✅ LinkedIn: max 5 hashtags, avslut med fråga/ställningstagande, Harvardkällor
- ✅ WordPress: H2 som artikelrubrik (inte H1), H3 för sektioner
